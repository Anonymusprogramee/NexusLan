"""
server/__main__.py
Punt d'entrada del servidor NexusLAN.
"""
import asyncio
import sys
import os

# Assegurar que el path del projecte és accessible
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server.core.server import run_server


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════╗
║           NEXUSLAN SERVER v1.0           ║
║  No cloud · No admin · No internet       ║
╚══════════════════════════════════════════╝
""")
    asyncio.run(run_server())
