"""
server/core/server.py  v2
"""
import asyncio
import logging
import time
import socket
from typing import Dict, Set

import websockets

from server.core.auth import AuthManager
from server.core.rooms import RoomManager
from server.database.repository import Repository
from server.networking.discovery import NexusDiscovery
from shared.protocol.messages import (
    Message,
    MSG_AUTH, MSG_AUTH_OK, MSG_AUTH_FAIL,
    MSG_MESSAGE, MSG_BROADCAST, MSG_HEARTBEAT,
    MSG_ROOM_JOIN, MSG_ROOM_LEAVE, MSG_ROOM_LIST,
    MSG_USER_LIST, MSG_USER_JOIN, MSG_USER_LEAVE,
    MSG_HISTORY, MSG_NOTIFICATION, MSG_ERROR,
    MSG_FILE_REQUEST, MSG_FILE_NOTIFY, MSG_FILE_ACCEPT,
    MSG_FILE_CHUNK, MSG_FILE_DONE, MSG_PING, MSG_PONG,
    now_ts
)

MSG_DM_HISTORY    = "dm_history"
MSG_ROOM_CREATE   = "room_create"
MSG_ROOM_CREATED  = "room_created"
MSG_FILE_REJECT   = "file_reject"
MSG_TYPING        = "typing"

logger = logging.getLogger("nexuslan.server")
SERVER_PORT = 5765
SERVER_HOST = "0.0.0.0"


class ClientSession:
    __slots__ = ("ws","username","hostname","role","rooms",
                 "last_heartbeat","cpu","ram","os_name","status","connected_at")

    def __init__(self, ws):
        self.ws             = ws
        self.username       = ""
        self.hostname       = ""
        self.role           = "user"
        self.rooms: Set[str]= set()
        self.last_heartbeat = time.time()
        self.cpu            = 0.0
        self.ram            = 0.0
        self.os_name        = ""
        self.status         = "online"
        self.connected_at   = int(time.time())

    @property
    def uid(self):
        return f"{self.username}@{self.hostname}"

    def to_dict(self):
        return {
            "username": self.username, "hostname": self.hostname,
            "uid": self.uid, "role": self.role,
            "cpu": self.cpu, "ram": self.ram, "os": self.os_name,
            "status": self.status, "connected_at": self.connected_at,
        }


class NexusServer:
    def __init__(self):
        self._repo      = Repository()
        self._rooms     = RoomManager()
        self._auth      = AuthManager(self._repo)
        self._discovery = NexusDiscovery(SERVER_PORT)
        self._sessions: Dict[object, ClientSession] = {}
        self._uid_map:  Dict[str, object] = {}

    async def start(self):
        await self._repo.connect()
        self._discovery.start()
        my_ip = self._get_local_ip()
        logger.info(f"IP local detectada: {my_ip}")
        async with websockets.serve(
            self._handle_client, SERVER_HOST, SERVER_PORT,
            ping_interval=20, ping_timeout=40,
            max_size=10*1024*1024,
        ):
            logger.info(f"✓ NexusLAN actiu al port {SERVER_PORT}")
            await asyncio.Future()

    async def stop(self):
        self._discovery.stop()
        await self._repo.close()

    async def _handle_client(self, ws):
        session = ClientSession(ws)
        try:
            if not await self._do_auth(ws, session):
                return
            self._sessions[ws] = session
            self._uid_map[session.uid] = ws
            self._rooms.join(ws, "general")
            session.rooms.add("general")
            await self._broadcast_all(
                Message(type=MSG_USER_JOIN, from_user=session.username,
                        from_host=session.hostname, data=session.to_dict()).to_json(),
                exclude=ws)
            await self._send_initial_state(ws, session)
            logger.info(f"CONNECT | {session.uid} | {ws.remote_address[0]}")
            async for raw in ws:
                await self._dispatch(ws, session, raw)
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            logger.exception(f"Error client {session.uid}: {e}")
        finally:
            await self._on_disconnect(ws, session)

    async def _do_auth(self, ws, session):
        try:
            raw = await asyncio.wait_for(ws.recv(), timeout=15.0)
            msg = Message.from_json(raw)
        except Exception:
            await ws.send(Message(type=MSG_AUTH_FAIL, content="Timeout").to_json())
            return False
        if msg.type != MSG_AUTH:
            await ws.send(Message(type=MSG_AUTH_FAIL, content="Primer missatge ha de ser auth").to_json())
            return False
        username = msg.from_user or "anonymous"
        data     = msg.data or {}
        hostname = data.get("hostname", "unknown")
        password = data.get("password")
        ok, role = await self._auth.authenticate(username, hostname, password)
        if not ok:
            await ws.send(Message(type=MSG_AUTH_FAIL, content="Credencials incorrectes").to_json())
            return False
        session.username = username
        session.hostname = hostname
        session.role     = role
        await ws.send(Message(type=MSG_AUTH_OK, from_user="server",
                               data={"role": role, "uid": session.uid}).to_json())
        return True

    async def _on_disconnect(self, ws, session):
        self._sessions.pop(ws, None)
        if self._uid_map.get(session.uid) is ws:
            self._uid_map.pop(session.uid, None)
        self._rooms.leave_all(ws)
        if session.username:
            logger.info(f"DISCONNECT | {session.uid}")
            await self._broadcast_all(
                Message(type=MSG_USER_LEAVE, from_user=session.username,
                        from_host=session.hostname,
                        data={"uid": session.uid}).to_json(), exclude=ws)

    async def _dispatch(self, ws, session, raw):
        try:
            msg = Message.from_json(raw)
        except Exception:
            await ws.send(Message(type=MSG_ERROR, content="JSON invàlid").to_json())
            return

        t = msg.type
        if   t == MSG_PING:          await ws.send(Message(type=MSG_PONG, timestamp=now_ts()).to_json())
        elif t == MSG_HEARTBEAT:     await self._h_heartbeat(ws, session, msg)
        elif t == MSG_MESSAGE:       await self._h_message(ws, session, msg)
        elif t == MSG_BROADCAST:     await self._h_broadcast(ws, session, msg)
        elif t == MSG_ROOM_JOIN:     await self._h_room_join(ws, session, msg)
        elif t == MSG_ROOM_LEAVE:    await self._h_room_leave(ws, session, msg)
        elif t == MSG_ROOM_LIST:     await self._h_room_list(ws, session)
        elif t == MSG_ROOM_CREATE:   await self._h_room_create(ws, session, msg)
        elif t == MSG_USER_LIST:     await self._h_user_list(ws, session)
        elif t == MSG_HISTORY:       await self._h_history(ws, session, msg)
        elif t == MSG_DM_HISTORY:    await self._h_dm_history(ws, session, msg)
        elif t == MSG_TYPING:        await self._h_typing(ws, session, msg)
        elif t == MSG_FILE_REQUEST:  await self._h_file_request(ws, session, msg)
        elif t in (MSG_FILE_ACCEPT, MSG_FILE_REJECT,
                   MSG_FILE_CHUNK, MSG_FILE_DONE,
                   "file_cancel", "react"):
                                     await self._h_file_relay(ws, session, msg)
        else:
            logger.debug(f"Tipus desconegut '{t}' de {session.uid}")

    # ---- handlers ----

    async def _h_heartbeat(self, ws, session, msg):
        session.last_heartbeat = time.time()
        d = msg.data or {}
        session.cpu    = d.get("cpu_percent", 0)
        session.ram    = d.get("ram_percent", 0)
        session.os_name= d.get("os", "")
        session.status = d.get("status", "online")
        await self._broadcast_all(
            Message(type=MSG_HEARTBEAT, from_user=session.username,
                    from_host=session.hostname, data=session.to_dict()).to_json(),
            exclude=ws)

    async def _h_message(self, ws, session, msg):
        to      = msg.to or "#general"
        content = (msg.content or "").strip()
        if not content:
            return
        # Comandes admin
        if content.startswith("/") and session.role in ("admin","moderator"):
            await self._run_command(ws, session, content)
            return
        out = Message(type=MSG_MESSAGE, from_user=session.username,
                      from_host=session.hostname, to=to, content=content,
                      msg_id=msg.msg_id, timestamp=now_ts())
        if to.startswith("#"):
            room = to[1:]
            await self._repo.save_message(msg.msg_id, session.username,
                                           session.hostname, room, None, content)
            await self._rooms.broadcast_room(room, out.to_json())
        else:
            # DM: guardar i enviar a ambdós
            await self._repo.save_dm(msg.msg_id, session.username,
                                      session.hostname, to, content)
            target_ws = self._uid_map.get(to)
            if target_ws:
                await target_ws.send(out.to_json())
            await ws.send(out.to_json())  # echo al remitent

    async def _run_command(self, ws, session, cmd):
        parts = cmd.strip().split(None, 2)
        verb  = parts[0].lower()
        if verb == "/broadcast" and len(parts) > 1:
            text = " ".join(parts[1:])
            await self._broadcast_all(
                Message(type=MSG_BROADCAST, from_user=session.username,
                        content=text, timestamp=now_ts()).to_json())
        elif verb == "/kick" and len(parts) > 1:
            tuid = parts[1]
            tws  = self._uid_map.get(tuid)
            if tws:
                await tws.send(Message(type=MSG_NOTIFICATION,
                                        content="Has estat expulsat.").to_json())
                await tws.close()
            else:
                await ws.send(Message(type=MSG_ERROR, content=f"No trobat: {tuid}").to_json())
        elif verb == "/rooms":
            await ws.send(Message(type=MSG_NOTIFICATION,
                                   content="Sales: " + ", ".join(self._rooms.all_rooms())).to_json())
        elif verb == "/users":
            await ws.send(Message(type=MSG_NOTIFICATION,
                                   content="Usuaris: " + ", ".join(self._uid_map.keys())).to_json())
        else:
            await ws.send(Message(type=MSG_ERROR, content=f"Comanda desconeguda: {verb}").to_json())

    async def _h_broadcast(self, ws, session, msg):
        if session.role not in ("admin","moderator"):
            await ws.send(Message(type=MSG_ERROR, content="Sense permisos").to_json())
            return
        await self._broadcast_all(
            Message(type=MSG_BROADCAST, from_user=session.username,
                    content=msg.content, timestamp=now_ts()).to_json())

    async def _h_room_join(self, ws, session, msg):
        room = (msg.data or {}).get("room","").lstrip("#")
        if not room: return
        self._rooms.join(ws, room)
        session.rooms.add(room)
        await ws.send(Message(type=MSG_ROOM_JOIN, data={"room": room}).to_json())

    async def _h_room_leave(self, ws, session, msg):
        room = (msg.data or {}).get("room","").lstrip("#")
        self._rooms.leave(ws, room)
        session.rooms.discard(room)

    async def _h_room_list(self, ws, session):
        rooms = await self._repo.get_rooms()
        for r in self._rooms.all_rooms():
            if not any(x["name"] == r for x in rooms):
                rooms.append({"name": r, "topic":"", "is_private":0})
        for r in rooms:
            r["member_count"] = len(self._rooms.members(r.get("name","")))
        await ws.send(Message(type=MSG_ROOM_LIST, data={"rooms": rooms}).to_json())

    async def _h_room_create(self, ws, session, msg):
        data  = msg.data or {}
        name  = data.get("name","").strip().lower().replace(" ","-")[:32]
        topic = data.get("topic","")
        if not name:
            await ws.send(Message(type=MSG_ERROR, content="Nom invàlid").to_json())
            return
        ok = await self._repo.create_room(name, topic, session.uid)
        if ok:
            self._rooms.ensure_room(name)
            await self._broadcast_all(
                Message(type=MSG_ROOM_CREATED, from_user=session.username,
                        data={"name": name, "topic": topic,
                              "created_by": session.uid}).to_json())
        else:
            await ws.send(Message(type=MSG_ERROR,
                                   content=f"La sala #{name} ja existeix").to_json())

    async def _h_user_list(self, ws, session):
        users = [s.to_dict() for s in self._sessions.values()]
        await ws.send(Message(type=MSG_USER_LIST, data={"users": users}).to_json())

    async def _h_history(self, ws, session, msg):
        d    = msg.data or {}
        room = d.get("room","general")
        lim  = min(int(d.get("limit",50)), 200)
        hist = await self._repo.get_room_history(room, lim)
        await ws.send(Message(type=MSG_HISTORY,
                               data={"room": room, "messages": hist}).to_json())

    async def _h_dm_history(self, ws, session, msg):
        d        = msg.data or {}
        with_uid = d.get("with","")
        lim      = min(int(d.get("limit",50)), 200)
        hist     = await self._repo.get_dm_history(session.uid, with_uid, lim)
        await ws.send(Message(type=MSG_DM_HISTORY,
                               data={"with": with_uid, "messages": hist}).to_json())

    async def _h_typing(self, ws, session, msg):
        to  = msg.to or ""
        out = Message(type=MSG_TYPING, from_user=session.username,
                      from_host=session.hostname, to=to, data=msg.data)
        if to.startswith("#"):
            await self._rooms.broadcast_room(to[1:], out.to_json(), exclude=ws)
        else:
            tws = self._uid_map.get(to)
            if tws:
                await tws.send(out.to_json())

    async def _h_file_request(self, ws, session, msg):
        to_uid  = msg.to or ""
        data    = msg.data or {}
        file_id = data.get("file_id","")
        await self._repo.record_transfer(
            file_id, session.uid, to_uid,
            data.get("filename","?"), data.get("size",0), data.get("checksum",""))
        tws = self._uid_map.get(to_uid)
        if tws:
            await tws.send(Message(type=MSG_FILE_NOTIFY,
                                    from_user=session.username, from_host=session.hostname,
                                    to=to_uid, data=data).to_json())
            logger.info(f"FILE_REQ | {session.uid}→{to_uid} | {data.get('filename')} {data.get('size',0)//1024}KB")
        else:
            await ws.send(Message(type=MSG_ERROR,
                                   content=f"Usuari {to_uid} no connectat").to_json())

    async def _h_file_relay(self, ws, session, msg):
        to_uid = msg.to or ""
        tws    = self._uid_map.get(to_uid)
        if tws:
            fwd = Message(type=msg.type, from_user=session.username,
                          from_host=session.hostname, to=to_uid,
                          content=msg.content, data=msg.data)
            await tws.send(fwd.to_json())
        if msg.type == MSG_FILE_DONE:
            file_id = (msg.data or {}).get("file_id","")
            if file_id:
                await self._repo.update_transfer_status(file_id, "done")
                logger.info(f"FILE_DONE | {file_id}")

    # ---- helpers ----

    async def _broadcast_all(self, raw, exclude=None):
        await self._rooms.broadcast_all(raw, exclude=exclude)

    async def _send_initial_state(self, ws, session):
        users = [s.to_dict() for s in self._sessions.values()]
        await ws.send(Message(type=MSG_USER_LIST, data={"users": users}).to_json())
        rooms = await self._repo.get_rooms()
        for r in rooms:
            r["member_count"] = len(self._rooms.members(r.get("name","")))
        await ws.send(Message(type=MSG_ROOM_LIST, data={"rooms": rooms}).to_json())
        hist = await self._repo.get_room_history("general", 50)
        await ws.send(Message(type=MSG_HISTORY,
                               data={"room":"general","messages":hist}).to_json())

    @staticmethod
    def _get_local_ip():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]; s.close(); return ip
        except Exception:
            return "127.0.0.1"


async def run_server():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s | %(levelname)s | %(message)s",
                        datefmt="%Y-%m-%d %H:%M:%S")
    srv = NexusServer()
    try:
        await srv.start()
    except KeyboardInterrupt:
        await srv.stop()

if __name__ == "__main__":
    asyncio.run(run_server())
