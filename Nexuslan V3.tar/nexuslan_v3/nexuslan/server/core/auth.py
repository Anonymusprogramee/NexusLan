"""
server/core/auth.py
Autenticació lleugera per NexusLAN.
V1: nom d'usuari lliure + hostname
V2: password opcional (bcrypt)
"""
import bcrypt
from typing import Optional


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


def sanitize_username(name: str) -> str:
    """Neteja el nom d'usuari: només alfanumèrics, guions i punts."""
    import re
    name = name.strip()[:32]
    name = re.sub(r"[^\w\-.]", "_", name)
    return name or "anonymous"


def sanitize_hostname(host: str) -> str:
    import re
    host = host.strip()[:64]
    host = re.sub(r"[^\w\-.]", "_", host)
    return host or "unknown"


class AuthManager:
    """
    Gestiona l'autenticació dels clients connectats.
    En V1 accepta qualsevol usuari. En V2 verifica password si existeix.
    """
    def __init__(self, repo):
        self._repo = repo
        self._require_password = False  # V1: False, V2: configurable

    def set_require_password(self, value: bool):
        self._require_password = value

    async def authenticate(self, username: str, hostname: str,
                           password: Optional[str] = None) -> tuple[bool, str]:
        """
        Retorna (ok, role).
        """
        username = sanitize_username(username)
        hostname = sanitize_hostname(hostname)
        
        # V1: autenticació lliure
        if not self._require_password:
            user = await self._repo.upsert_user(username, hostname)
            return True, user.get("role", "user")
        
        # V2: verificació de password
        user = await self._repo.upsert_user(username, hostname)
        stored_hash = user.get("password_hash")
        
        if stored_hash is None:
            # Primer login: guardar hash
            if password:
                ph = hash_password(password)
                await self._repo.upsert_user(username, hostname, password_hash=ph)
            return True, user.get("role", "user")
        
        if password and verify_password(password, stored_hash):
            return True, user.get("role", "user")
        
        return False, ""
