"""
server/core/rooms.py
Gestió de sales i membres en memòria.
"""
from typing import Dict, Set, Optional
import websockets


class RoomManager:
    def __init__(self):
        # room_name → set of websocket connections
        self._rooms: Dict[str, Set] = {
            "general": set(),
            "admins": set(),
            "broadcast": set(),
        }
        # ws → set of rooms
        self._client_rooms: Dict[object, Set[str]] = {}

    def ensure_room(self, name: str):
        if name not in self._rooms:
            self._rooms[name] = set()

    def join(self, ws, room: str):
        self.ensure_room(room)
        self._rooms[room].add(ws)
        self._client_rooms.setdefault(ws, set()).add(room)

    def leave(self, ws, room: str):
        if room in self._rooms:
            self._rooms[room].discard(ws)
        if ws in self._client_rooms:
            self._client_rooms[ws].discard(room)

    def leave_all(self, ws):
        rooms = self._client_rooms.pop(ws, set())
        for room in rooms:
            if room in self._rooms:
                self._rooms[room].discard(ws)

    def members(self, room: str) -> Set:
        return self._rooms.get(room, set())

    def client_rooms(self, ws) -> Set[str]:
        return self._client_rooms.get(ws, set())

    def all_rooms(self):
        return list(self._rooms.keys())

    async def broadcast_room(self, room: str, message: str, exclude=None):
        """Envia un missatge a tots els membres d'una sala."""
        members = self.members(room).copy()
        for ws in members:
            if ws is exclude:
                continue
            try:
                await ws.send(message)
            except Exception:
                pass

    async def broadcast_all(self, message: str, exclude=None):
        """Envia un missatge a tots els clients connectats."""
        all_ws = set()
        for members in self._rooms.values():
            all_ws.update(members)
        for ws in all_ws:
            if ws is exclude:
                continue
            try:
                await ws.send(message)
            except Exception:
                pass
