"""
server/networking/discovery.py
Anunci del servidor via mDNS/Zeroconf. No requereix permisos d'admin.
"""
import socket
import logging
from zeroconf import Zeroconf, ServiceInfo

logger = logging.getLogger("nexuslan.discovery")

SERVICE_TYPE = "_nexuslan._tcp.local."
SERVICE_NAME = "NexusLAN-Core._nexuslan._tcp.local."


def _get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


class NexusDiscovery:
    def __init__(self, port: int):
        self._port = port
        self._zc: Zeroconf | None = None
        self._info: ServiceInfo | None = None

    def start(self):
        try:
            local_ip = _get_local_ip()
            self._zc = Zeroconf()
            self._info = ServiceInfo(
                SERVICE_TYPE,
                SERVICE_NAME,
                addresses=[socket.inet_aton(local_ip)],
                port=self._port,
                properties={b"version": b"1.0", b"app": b"nexuslan"},
            )
            self._zc.register_service(self._info)
            logger.info(f"mDNS: servei anunciat a {local_ip}:{self._port}")
        except Exception as e:
            logger.warning(f"mDNS no disponible: {e} (el servidor segueix funcionant)")

    def stop(self):
        if self._zc and self._info:
            try:
                self._zc.unregister_service(self._info)
                self._zc.close()
            except Exception:
                pass
