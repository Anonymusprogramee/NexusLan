"""
server/database/repository.py v2
Afegit: save_dm, get_dm_history
"""
import aiosqlite
import time
from typing import Optional, List, Dict

from server.database.models import CREATE_TABLES, DEFAULT_ROOMS
from shared.utils.paths import get_db_path


class Repository:
    def __init__(self):
        self._db_path = str(get_db_path())
        self._db = None

    async def connect(self):
        self._db = await aiosqlite.connect(self._db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.executescript(CREATE_TABLES)
        await self._ensure_default_rooms()
        await self._db.commit()

    async def close(self):
        if self._db:
            await self._db.close()

    async def _ensure_default_rooms(self):
        for name, topic, private in DEFAULT_ROOMS:
            await self._db.execute(
                "INSERT OR IGNORE INTO rooms(name,topic,is_private) VALUES(?,?,?)",
                (name, topic, private))

    async def get_rooms(self) -> List[Dict]:
        async with self._db.execute("SELECT * FROM rooms WHERE is_private=0") as cur:
            return [dict(r) for r in await cur.fetchall()]

    async def create_room(self, name: str, topic: str = "", created_by: str = "") -> bool:
        try:
            await self._db.execute(
                "INSERT INTO rooms(name,topic,created_by) VALUES(?,?,?)",
                (name, topic, created_by))
            await self._db.commit()
            return True
        except Exception:
            return False

    async def upsert_user(self, username, hostname, role="user", password_hash=None) -> Dict:
        await self._db.execute(
            """INSERT INTO users(username,hostname,role,password_hash,last_seen)
               VALUES(?,?,?,?,?)
               ON CONFLICT(username,hostname) DO UPDATE SET
               last_seen=excluded.last_seen""",
            (username, hostname, role, password_hash, int(time.time())))
        await self._db.commit()
        async with self._db.execute(
            "SELECT * FROM users WHERE username=? AND hostname=?", (username,hostname)
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else {}

    async def get_user_role(self, username, hostname) -> str:
        async with self._db.execute(
            "SELECT role FROM users WHERE username=? AND hostname=?", (username,hostname)
        ) as cur:
            row = await cur.fetchone()
            return row["role"] if row else "user"

    async def save_message(self, msg_id, from_user, from_host, room, to_user, content, encrypted=False):
        await self._db.execute(
            "INSERT INTO messages(msg_id,from_user,from_host,room,to_user,content,encrypted) VALUES(?,?,?,?,?,?,?)",
            (msg_id, from_user, from_host, room, to_user, content, int(encrypted)))
        await self._db.commit()

    async def save_dm(self, msg_id, from_user, from_host, to_uid, content):
        """Guarda un missatge directe. to_uid = 'user@host'"""
        await self._db.execute(
            "INSERT INTO messages(msg_id,from_user,from_host,room,to_user,content) VALUES(?,?,?,?,?,?)",
            (msg_id, from_user, from_host, None, to_uid, content))
        await self._db.commit()

    async def get_room_history(self, room: str, limit: int = 50) -> List[Dict]:
        async with self._db.execute(
            "SELECT * FROM messages WHERE room=? ORDER BY timestamp DESC LIMIT ?",
            (room, limit)
        ) as cur:
            rows = await cur.fetchall()
            return [dict(r) for r in reversed(rows)]

    async def get_dm_history(self, uid_a: str, uid_b: str, limit: int = 50) -> List[Dict]:
        """Historial de DMs entre uid_a i uid_b (en qualsevol direcció)."""
        # uid_a = "user@host", uid_b = "user@host"
        # from_user+from_host → 'user@host' NO funciona directament a SQLite
        # Guardem to_user com uid complert i filtrem per parells
        async with self._db.execute(
            """SELECT * FROM messages
               WHERE room IS NULL AND (
                 (from_user || '@' || from_host = ? AND to_user = ?)
                 OR
                 (from_user || '@' || from_host = ? AND to_user = ?)
               )
               ORDER BY timestamp DESC LIMIT ?""",
            (uid_a, uid_b, uid_b, uid_a, limit)
        ) as cur:
            rows = await cur.fetchall()
            return [dict(r) for r in reversed(rows)]

    async def record_transfer(self, file_id, from_user, to_user, filename, size, checksum):
        await self._db.execute(
            "INSERT OR REPLACE INTO file_transfers(file_id,from_user,to_user,filename,size_bytes,checksum) VALUES(?,?,?,?,?,?)",
            (file_id, from_user, to_user, filename, size, checksum))
        await self._db.commit()

    async def update_transfer_status(self, file_id, status):
        await self._db.execute(
            "UPDATE file_transfers SET status=? WHERE file_id=?", (status, file_id))
        await self._db.commit()
