"""
server/database/models.py
Schema SQLite per NexusLAN. Guardat a ~/.config/nexuslan/nexuslan.db
"""
CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT NOT NULL,
    hostname    TEXT NOT NULL,
    password_hash TEXT,
    role        TEXT DEFAULT 'user',   -- user | moderator | admin
    created_at  INTEGER DEFAULT (strftime('%s','now')),
    last_seen   INTEGER,
    UNIQUE(username, hostname)
);

CREATE TABLE IF NOT EXISTS rooms (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    topic       TEXT,
    is_private  INTEGER DEFAULT 0,
    created_by  TEXT,
    created_at  INTEGER DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    msg_id      TEXT NOT NULL,
    from_user   TEXT NOT NULL,
    from_host   TEXT NOT NULL,
    room        TEXT,
    to_user     TEXT,
    content     TEXT,
    encrypted   INTEGER DEFAULT 0,
    timestamp   INTEGER DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS file_transfers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id     TEXT NOT NULL UNIQUE,
    from_user   TEXT NOT NULL,
    to_user     TEXT,
    filename    TEXT NOT NULL,
    size_bytes  INTEGER,
    checksum    TEXT,
    status      TEXT DEFAULT 'pending',  -- pending | done | failed
    timestamp   INTEGER DEFAULT (strftime('%s','now'))
);

CREATE INDEX IF NOT EXISTS idx_messages_room ON messages(room);
CREATE INDEX IF NOT EXISTS idx_messages_ts   ON messages(timestamp);
"""

DEFAULT_ROOMS = [
    ("general",   "Canal principal per a tothom", 0),
    ("admins",    "Canal restringit per a admins", 1),
    ("broadcast", "Anuncis del servidor",          1),
]
