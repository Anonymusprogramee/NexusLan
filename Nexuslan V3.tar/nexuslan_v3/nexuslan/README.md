# NexusLAN

> Chat LAN local · Sense internet · Sense núvol · Sense comptes · **Sense permisos d'administrador**

```
╔══════════════════════════════════════════╗
║           NEXUSLAN SERVER v1.0           ║
║  No cloud · No admin · No internet       ║
╚══════════════════════════════════════════╝
```

## Característiques

- 💬 **Missatgeria en temps real** — sales i missatges privats
- 🔍 **Descobriment automàtic** — via mDNS/Zeroconf, sense configurar IPs
- 📊 **Dashboard en viu** — CPU, RAM, ping de cada client
- 📁 **Transferència de fitxers** — chunks + checksum SHA-256, fins 100MB
- 🎨 **UI dark cyberpunk** — PyQt6 amb tema hacker
- 🔒 **100% sense admin** — ports > 1024, dades a directori d'usuari
- 🔐 **Encriptació AES-256-GCM** (V3)

## Ports

| Servei | Port | Protocol |
|--------|------|----------|
| Servidor principal | 5765 | TCP WebSocket |
| Descobriment mDNS | 5766 | UDP (automàtic) |
| Transferència | 5767 | TCP (futur) |

## Instal·lació

```bash
git clone https://github.com/el-teu-usuari/nexuslan
cd nexuslan
pip install -r requirements.txt
```

## Ús

### Servidor

```bash
# Directament
python -m server

# Via Docker (sense sudo si l'usuari és al grup docker)
docker-compose -f docker/docker-compose.yml up
```

### Client

```bash
python -m client
```

La UI de login apareixerà. Posa el teu nom d'usuari i deixa la IP en blanc per a descobriment automàtic.

## Estructura del projecte

```
nexuslan/
├── server/
│   ├── core/
│   │   ├── server.py       ← WebSocket server (asyncio)
│   │   ├── auth.py         ← Autenticació V1/V2
│   │   └── rooms.py        ← Gestió de sales
│   ├── database/
│   │   ├── models.py       ← Schema SQLite
│   │   └── repository.py   ← CRUD asyncio
│   └── networking/
│       └── discovery.py    ← mDNS/Zeroconf
│
├── client/
│   ├── ui/
│   │   ├── main_window.py  ← Finestra principal
│   │   ├── chat_view.py    ← Vista de xat
│   │   ├── users_panel.py  ← Panel d'usuaris
│   │   └── styles/
│   │       └── dark_theme.qss
│   ├── networking/
│   │   ├── client.py       ← WebSocket client
│   │   └── discovery.py    ← Descobriment servidor
│   └── services/
│       └── system_info.py  ← CPU/RAM
│
├── shared/
│   ├── protocol/
│   │   └── messages.py     ← Tots els tipus de missatge
│   ├── encryption/
│   │   └── aes_gcm.py      ← AES-256-GCM
│   └── utils/
│       └── paths.py        ← Paths multiplataforma
│
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
└── requirements.txt
```

## Arquitectura

```
┌─────────────────────────────────────┐
│         SERVIDOR NEXUSLAN            │
│  WebSocket asyncio · SQLite · mDNS   │
│  Port 5765 · ~/.config/nexuslan/     │
└──────────────┬──────────────────────┘
               │ WebSocket (ws://)
    ┌──────────┼──────────┐
    │          │          │
 CLIENT A   CLIENT B   CLIENT C
 (PyQt6)   (PyQt6)    (PyQt6)
```

## Protocol de missatgeria

Tots els missatges viatgen com JSON per WebSocket:

```json
{
  "type": "message",
  "from": "sergi",
  "host": "PC-AULA-14",
  "to": "#SMX1",
  "content": "Hola!",
  "timestamp": 1746612000,
  "msg_id": "a3f2b1c4"
}
```

## Roadmap

| Versió | Estat | Contingut |
|--------|-------|-----------|
| **V1** | ✅ MVP | Servidor + Client PyQt6 + mDNS + Sales |
| **V2** | ✅ MVP | Fitxers + Auth bcrypt + Dashboard stats |
| **V3** | 🔄 Pendent | AES-256-GCM E2E + Web dashboard + Docker |
| **V4** | 🚀 Futur | Plugin system + Wake-on-LAN + Installers |

## Nota tècnica

Tot el projecte corre en **espai d'usuari**:
- Cap socket raw
- Cap port < 1024  
- Cap servei de sistema
- Cap escriptura fora de `~/.config/nexuslan/` i `~/Downloads/NexusLAN/`

Verificat per Windows 10/11, Ubuntu 22.04+, macOS 13+.

---

*NexusLAN — LAN communication for institutes, labs, offices and homelabs.*
