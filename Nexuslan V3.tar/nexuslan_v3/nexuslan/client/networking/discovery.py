"""
client/networking/discovery.py
Descobriment automàtic del servidor NexusLAN via mDNS/Zeroconf.
"""
import asyncio
import logging
import socket
from typing import Optional

SERVICE_TYPE = "_nexuslan._tcp.local."
logger = logging.getLogger("nexuslan.discovery")


async def find_server(timeout: float = 5.0) -> Optional[str]:
    """
    Busca un servidor NexusLAN a la xarxa local via mDNS.
    Retorna la IP si la troba, o None.
    """
    try:
        from zeroconf import Zeroconf, ServiceBrowser
        found_ip: list = []
        done = asyncio.Event()

        class Handler:
            def add_service(self, zc, type_, name):
                info = zc.get_service_info(type_, name)
                if info and info.addresses:
                    ip = socket.inet_ntoa(info.addresses[0])
                    found_ip.append(ip)
                    done.set()

            def remove_service(self, *_): pass
            def update_service(self, *_): pass

        zc = Zeroconf()
        browser = ServiceBrowser(zc, SERVICE_TYPE, Handler())
        
        try:
            await asyncio.wait_for(done.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            pass
        finally:
            zc.close()
        
        return found_ip[0] if found_ip else None
    except Exception as e:
        logger.warning(f"Error en descobriment mDNS: {e}")
        return None
