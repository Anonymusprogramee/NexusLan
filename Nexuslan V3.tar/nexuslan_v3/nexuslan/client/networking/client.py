"""
client/networking/client.py  v3
Correccions:
 - Transferència fitxers amb handshake real (espera FILE_ACCEPT)
 - Reconexió robusta amb backoff
 - Suport cancel·lació de transferències
 - Nous tipus: react, file_cancel
"""
import asyncio
import base64
import hashlib
import logging
import platform
import socket as _socket
import time
import uuid
from pathlib import Path
from typing import Callable, Dict, Optional

import psutil
import websockets

from shared.protocol.messages import (
    Message,
    MSG_AUTH, MSG_PING, MSG_PONG,
    MSG_HEARTBEAT, MSG_MESSAGE, MSG_BROADCAST,
    MSG_ROOM_JOIN, MSG_ROOM_LIST, MSG_USER_LIST,
    MSG_ROOM_LEAVE, MSG_HISTORY, MSG_NOTIFICATION,
    MSG_AUTH_OK, MSG_AUTH_FAIL, MSG_ERROR,
    MSG_USER_JOIN, MSG_USER_LEAVE,
    MSG_FILE_REQUEST, MSG_FILE_NOTIFY, MSG_FILE_ACCEPT,
    MSG_FILE_CHUNK, MSG_FILE_DONE,
    make_auth, make_heartbeat,
)
from client.networking.discovery import find_server
from shared.utils.paths import get_downloads_dir

MSG_DM_HISTORY   = "dm_history"
MSG_ROOM_CREATE  = "room_create"
MSG_ROOM_CREATED = "room_created"
MSG_FILE_REJECT  = "file_reject"
MSG_FILE_CANCEL  = "file_cancel"
MSG_TYPING       = "typing"
MSG_REACT        = "react"

logger      = logging.getLogger("nexuslan.client")
SERVER_PORT = 5765


class FileReceiver:
    def __init__(self, file_id, filename, size, checksum, from_uid):
        self.file_id  = file_id
        self.filename = filename
        self.size     = size
        self.checksum = checksum
        self.from_uid = from_uid
        self.chunks: Dict[int, bytes] = {}
        self.total    = 0
        self.received = 0

    def add_chunk(self, n, total, data_b64):
        self.total     = total
        self.chunks[n] = base64.b64decode(data_b64)
        self.received  = len(self.chunks)

    @property
    def progress(self):
        return self.received / self.total if self.total else 0.0

    def save(self):
        """Retorna (Path, checksum_ok) o (None, False)."""
        if not self.chunks:
            return None, False
        data = b"".join(self.chunks[i] for i in sorted(self.chunks))
        ok   = hashlib.sha256(data).hexdigest() == self.checksum
        dst  = get_downloads_dir() / self.filename
        c    = 1
        while dst.exists():
            stem, suf = Path(self.filename).stem, Path(self.filename).suffix
            dst = get_downloads_dir() / f"{stem}_{c}{suf}"
            c  += 1
        dst.write_bytes(data)
        return dst, ok


class FileSender:
    def __init__(self, file_id, filepath, to_uid):
        self.file_id   = file_id
        self.filepath  = Path(filepath)
        self.to_uid    = to_uid
        self.accepted  = asyncio.Event()
        self.rejected  = asyncio.Event()
        self.cancelled = False


class NexusClient:
    def __init__(self, username, hostname=None, password=None):
        self.username = username
        self.hostname = hostname or _socket.gethostname()
        self.password = password
        self._ws:     Optional[websockets.WebSocketClientProtocol] = None
        self._connected   = False
        self._server_ip   = None
        self._ping_sent   = 0.0
        self.latency_ms   = 0.0
        self._reconnect_n = 0
        self._stop        = False
        self._incoming: Dict[str, FileReceiver] = {}
        self._outgoing: Dict[str, FileSender]   = {}

        self.on_message      = None
        self.on_user_join    = None
        self.on_user_leave   = None
        self.on_user_list    = None
        self.on_room_list    = None
        self.on_room_created = None
        self.on_history      = None
        self.on_dm_history   = None
        self.on_broadcast    = None
        self.on_heartbeat    = None
        self.on_file_notify  = None
        self.on_file_progress = None  # (file_id, pct, filename, direction)
        self.on_file_done    = None   # (file_id, path, checksum_ok, filename, from_uid)
        self.on_file_reject  = None
        self.on_file_cancel  = None
        self.on_typing       = None
        self.on_react        = None
        self.on_notification = None
        self.on_auth_ok      = None
        self.on_auth_fail    = None
        self.on_error        = None
        self.on_disconnect   = None
        self.on_ping_update  = None

    @property
    def connected(self):
        return self._connected

    @property
    def uid(self):
        return f"{self.username}@{self.hostname}"

    # ---- connect ----

    async def connect(self, server_ip=None):
        self._stop = False
        if server_ip is None:
            server_ip = await find_server()
            if not server_ip:
                return False
        self._server_ip = server_ip
        return await self._do_connect()

    async def _do_connect(self):
        uri = f"ws://{self._server_ip}:{SERVER_PORT}"
        try:
            self._ws = await websockets.connect(
                uri, ping_interval=15, ping_timeout=30,
                max_size=10 * 1024 * 1024)
            self._connected   = True
            self._reconnect_n = 0
            await self._authenticate()
            asyncio.ensure_future(self._recv_loop())
            asyncio.ensure_future(self._hb_loop())
            asyncio.ensure_future(self._ping_loop())
            return True
        except Exception as e:
            logger.error(f"Connexió fallida a {uri}: {e}")
            self._connected = False
            return False

    async def disconnect(self):
        self._stop = True
        self._connected = False
        for s in self._outgoing.values():
            s.cancelled = True
            s.rejected.set()
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
        if self.on_disconnect:
            self.on_disconnect()

    # ---- send helpers ----

    async def send_chat(self, to, content):
        await self._send(Message(type=MSG_MESSAGE, from_user=self.username,
                                  from_host=self.hostname, to=to, content=content))

    async def send_typing(self, to, is_typing):
        await self._send(Message(type=MSG_TYPING, from_user=self.username,
                                  from_host=self.hostname, to=to,
                                  data={"typing": is_typing}))

    async def send_react(self, msg_id, to, emoji):
        await self._send(Message(type=MSG_REACT, from_user=self.username,
                                  from_host=self.hostname, to=to,
                                  data={"msg_id": msg_id, "emoji": emoji}))

    async def send_broadcast(self, content):
        await self._send(Message(type=MSG_BROADCAST, from_user=self.username,
                                  content=content))

    async def join_room(self, room):
        room = room.lstrip("#")
        await self._send(Message(type=MSG_ROOM_JOIN, data={"room": room}))
        await self._send(Message(type=MSG_HISTORY,   data={"room": room, "limit": 50}))

    async def leave_room(self, room):
        await self._send(Message(type=MSG_ROOM_LEAVE,
                                  data={"room": room.lstrip("#")}))

    async def create_room(self, name, topic=""):
        await self._send(Message(type=MSG_ROOM_CREATE,
                                  data={"name": name, "topic": topic}))

    async def request_dm_history(self, with_uid, limit=50):
        await self._send(Message(type=MSG_DM_HISTORY,
                                  data={"with": with_uid, "limit": limit}))

    async def request_room_list(self):
        await self._send(Message(type=MSG_ROOM_LIST))

    async def request_user_list(self):
        await self._send(Message(type=MSG_USER_LIST))

    async def accept_file(self, to_uid, file_id):
        await self._send(Message(type=MSG_FILE_ACCEPT, from_user=self.username,
                                  from_host=self.hostname, to=to_uid,
                                  data={"file_id": file_id}))

    async def reject_file(self, to_uid, file_id):
        self._incoming.pop(file_id, None)
        await self._send(Message(type=MSG_FILE_REJECT, from_user=self.username,
                                  from_host=self.hostname, to=to_uid,
                                  data={"file_id": file_id}))

    async def cancel_send(self, file_id):
        sender = self._outgoing.get(file_id)
        if sender:
            sender.cancelled = True
            sender.rejected.set()
            await self._send(Message(type=MSG_FILE_CANCEL, to=sender.to_uid,
                                      data={"file_id": file_id}))

    # ---- file send (main entry point) ----

    async def send_file(self, filepath: str, to_uid: str) -> bool:
        """
        Envia un fitxer. Espera que el receptor accepti (màx 60s).
        Retorna True si completat, False si rebutjat/cancel·lat/timeout.
        """
        p = Path(filepath)
        if not p.exists():
            return False
        size = p.stat().st_size
        if size > 500 * 1024 * 1024:
            if self.on_error:
                self.on_error(Message(type=MSG_ERROR,
                                      content="Fitxer massa gran (>500MB)"))
            return False

        # Calcular checksum
        sha = hashlib.sha256()
        with open(filepath, "rb") as f:
            for block in iter(lambda: f.read(65536), b""):
                sha.update(block)
        checksum = sha.hexdigest()
        file_id  = str(uuid.uuid4())[:8]

        sender = FileSender(file_id, p, to_uid)
        self._outgoing[file_id] = sender

        # 1. Enviar petició
        await self._send(Message(
            type=MSG_FILE_REQUEST, from_user=self.username,
            from_host=self.hostname, to=to_uid,
            data={"filename": p.name, "size": size,
                  "file_id": file_id, "checksum": checksum}
        ))

        # 2. Esperar acceptació o rebuig (60s timeout)
        acc_task = asyncio.ensure_future(sender.accepted.wait())
        rej_task = asyncio.ensure_future(sender.rejected.wait())
        done, pending = await asyncio.wait(
            [acc_task, rej_task], timeout=60.0,
            return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()

        if sender.cancelled or sender.rejected.is_set() or not done:
            self._outgoing.pop(file_id, None)
            return False

        # 3. Enviar chunks
        CHUNK = 64 * 1024
        with open(filepath, "rb") as f:
            raw = f.read()
        total = max(1, (len(raw) + CHUNK - 1) // CHUNK)

        for i in range(total):
            if sender.cancelled:
                self._outgoing.pop(file_id, None)
                return False
            chunk = raw[i * CHUNK:(i + 1) * CHUNK]
            await self._send(Message(
                type=MSG_FILE_CHUNK, from_user=self.username,
                from_host=self.hostname, to=to_uid,
                data={"file_id": file_id, "chunk": base64.b64encode(chunk).decode(),
                      "n": i + 1, "total": total}
            ))
            pct = (i + 1) / total
            if self.on_file_progress:
                self.on_file_progress(file_id, pct, p.name, "send")
            await asyncio.sleep(0.002)

        # 4. Finalitzar
        await self._send(Message(type=MSG_FILE_DONE, to=to_uid,
                                  data={"file_id": file_id}))
        if self.on_file_progress:
            self.on_file_progress(file_id, 1.0, p.name, "send")

        self._outgoing.pop(file_id, None)
        return True

    # ---- internal loops ----

    async def _authenticate(self):
        await self._ws.send(make_auth(self.username, self.hostname,
                                       self.password).to_json())

    async def _recv_loop(self):
        try:
            async for raw in self._ws:
                await self._dispatch(raw)
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            logger.exception(f"recv_loop error: {e}")
        finally:
            self._connected = False
            for s in self._outgoing.values():
                s.cancelled = True
                s.rejected.set()
            if self.on_disconnect:
                self.on_disconnect()
            if not self._stop:
                asyncio.ensure_future(self._reconnect())

    async def _reconnect(self):
        if self._reconnect_n >= 10 or self._stop:
            return
        self._reconnect_n += 1
        delay = min(5 * self._reconnect_n, 30)
        logger.info(f"Reconexió {self._reconnect_n}/10 en {delay}s…")
        await asyncio.sleep(delay)
        if not await self._do_connect():
            asyncio.ensure_future(self._reconnect())

    async def _hb_loop(self):
        while self._connected:
            try:
                cpu = psutil.cpu_percent(interval=None)
                ram = psutil.virtual_memory().percent
                os_ = f"{platform.system()} {platform.release()}"
                await self._send(make_heartbeat(self.username, self.hostname,
                                                os_, cpu, ram))
            except Exception:
                pass
            await asyncio.sleep(15)

    async def _ping_loop(self):
        while self._connected:
            await asyncio.sleep(8)
            if self._ws and self._connected:
                self._ping_sent = time.time()
                await self._send(Message(type=MSG_PING))

    async def _send(self, msg: Message):
        if self._ws and self._connected:
            try:
                await self._ws.send(msg.to_json())
            except Exception as e:
                logger.error(f"Send error ({msg.type}): {e}")

    # ---- dispatch ----

    async def _dispatch(self, raw: str):
        try:
            msg = Message.from_json(raw)
        except Exception:
            return
        t = msg.type

        if t == MSG_PONG:
            if self._ping_sent:
                self.latency_ms = (time.time() - self._ping_sent) * 1000
                if self.on_ping_update:
                    self.on_ping_update(self.latency_ms)
            return

        if t == MSG_FILE_ACCEPT:
            fid = (msg.data or {}).get("file_id", "")
            s   = self._outgoing.get(fid)
            if s:
                s.accepted.set()
            return

        if t == MSG_FILE_REJECT:
            fid = (msg.data or {}).get("file_id", "")
            s   = self._outgoing.get(fid)
            if s:
                s.rejected.set()
            if self.on_file_reject:
                self.on_file_reject(msg)
            return

        if t == MSG_FILE_CANCEL:
            fid = (msg.data or {}).get("file_id", "")
            self._incoming.pop(fid, None)
            if self.on_file_cancel:
                self.on_file_cancel(msg)
            return

        if t == MSG_FILE_NOTIFY:
            d   = msg.data or {}
            fid = d.get("file_id", "")
            self._incoming[fid] = FileReceiver(
                file_id  = fid,
                filename = d.get("filename", "fitxer"),
                size     = d.get("size", 0),
                checksum = d.get("checksum", ""),
                from_uid = f"{msg.from_user}@{msg.from_host}"
            )
            if self.on_file_notify:
                self.on_file_notify(msg)
            return

        if t == MSG_FILE_CHUNK:
            d    = msg.data or {}
            fid  = d.get("file_id", "")
            recv = self._incoming.get(fid)
            if recv:
                recv.add_chunk(d.get("n", 1), d.get("total", 1), d.get("chunk", ""))
                if self.on_file_progress:
                    self.on_file_progress(fid, recv.progress, recv.filename, "recv")
            return

        if t == MSG_FILE_DONE:
            fid  = (msg.data or {}).get("file_id", "")
            recv = self._incoming.pop(fid, None)
            if recv:
                path, ok = recv.save()
                if self.on_file_done:
                    self.on_file_done(fid, path, ok, recv.filename, recv.from_uid)
            return

        cb = {
            MSG_AUTH_OK:      self.on_auth_ok,
            MSG_AUTH_FAIL:    self.on_auth_fail,
            MSG_MESSAGE:      self.on_message,
            MSG_BROADCAST:    self.on_broadcast,
            MSG_USER_JOIN:    self.on_user_join,
            MSG_USER_LEAVE:   self.on_user_leave,
            MSG_USER_LIST:    self.on_user_list,
            MSG_ROOM_LIST:    self.on_room_list,
            MSG_ROOM_CREATED: self.on_room_created,
            MSG_HEARTBEAT:    self.on_heartbeat,
            MSG_HISTORY:      self.on_history,
            MSG_DM_HISTORY:   self.on_dm_history,
            MSG_TYPING:       self.on_typing,
            MSG_REACT:        self.on_react,
            MSG_NOTIFICATION: self.on_notification,
            MSG_ERROR:        self.on_error,
        }.get(t)
        if cb:
            cb(msg)
