"""
client/__main__.py
Punt d'entrada del client NexusLAN.
Integra asyncio amb PyQt6 via qasync.
"""
import sys
import asyncio

from PyQt6.QtWidgets import QApplication
import qasync

from client.ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("NexusLAN")
    app.setOrganizationName("NexusLAN")

    loop = qasync.QEventLoop(app)
    asyncio.set_event_loop(loop)

    window = MainWindow()
    window.show()

    with loop:
        loop.run_forever()


if __name__ == "__main__":
    main()
