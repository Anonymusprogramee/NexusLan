"""
client/ui/main_window.py  v3
Correccions i millores:
 - DMs: s'obren automàticament quan reps un missatge, badge unread correcte
 - Fitxers: handshake real, barra de progrés funcional, cancel·lació
 - Signals thread-safe per TOTS els callbacks de xarxa
 - Indicador d'escriptura visible a la UI
 - Nou: reaccions amb emojis, cerca de missatges, broadcast per admins
 - Nou: botó per obrir carpeta de descàrregues
"""
import asyncio
import os
import socket
import time
from pathlib import Path
from typing import Dict, Optional

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QListWidget, QListWidgetItem, QDialog,
    QDialogButtonBox, QLineEdit, QFormLayout, QFrame,
    QFileDialog, QMessageBox, QPushButton, QProgressBar,
    QApplication, QSizePolicy, QScrollArea
)
from PyQt6.QtCore import Qt, QTimer, pyqtSlot, pyqtSignal
from PyQt6.QtGui import QFont

from client.networking.client import NexusClient
from client.ui.chat_view import ChatView
from client.ui.users_panel import UsersPanel
from shared.protocol.messages import Message
from shared.utils.paths import get_downloads_dir


def load_stylesheet(path: str) -> str:
    try:
        with open(path) as f:
            return f.read()
    except Exception:
        return ""


# ─────────────────────────────────────────────────────────
#  Diàlegs
# ─────────────────────────────────────────────────────────

class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("login_dialog")
        self.setWindowTitle("NexusLAN - Connexio")
        self.setMinimumWidth(430)
        self.setModal(True)
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(32, 30, 32, 24)

        logo = QLabel("NEXUSLAN")
        logo.setObjectName("logo_label")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)

        tag = QLabel("Xat local segur per a la teva LAN")
        tag.setObjectName("tagline_label")
        tag.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(tag)

        form = QFormLayout()
        form.setSpacing(10)
        self._user = QLineEdit()
        self._user.setText(os.environ.get("USER", os.environ.get("USERNAME", "")))
        self._user.setPlaceholderText("Nom visible")
        form.addRow("Usuari:", self._user)

        self._host = QLineEdit()
        self._host.setPlaceholderText("Deixa-ho buit per usar aquest equip")
        form.addRow("Hostname:", self._host)

        self._ip = QLineEdit()
        self._ip.setPlaceholderText("Buit = descobrir servidor automaticament")
        form.addRow("Servidor IP:", self._ip)
        layout.addLayout(form)

        note = QLabel("Sense IP, NexusLAN buscara el servidor a la xarxa local.")
        note.setStyleSheet("color: #8d99aa; font-size: 11px;")
        note.setWordWrap(True)
        layout.addWidget(note)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self._user.setFocus()

    @property
    def username(self): return self._user.text().strip() or "anonymous"
    @property
    def hostname(self): return self._host.text().strip() or socket.gethostname()
    @property
    def server_ip(self):
        t = self._ip.text().strip()
        return t or None


class FileNotifyDialog(QDialog):
    def __init__(self, from_uid, filename, size, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Fitxer entrant")
        self.setModal(True)
        self.setMinimumWidth(360)
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 24, 24, 20)

        layout.addWidget(QLabel(f"<b>{from_uid}</b> vol enviar-te un fitxer:"))
        layout.addWidget(QLabel(f"<b>{filename}</b>"))
        size_str = (f"{size/1024:.1f} KB" if size < 1024*1024
                    else f"{size/1024/1024:.1f} MB")
        layout.addWidget(QLabel(f"Mida: {size_str}"))

        btns = QDialogButtonBox()
        btns.addButton("Acceptar", QDialogButtonBox.ButtonRole.AcceptRole)
        btns.addButton("Rebutjar", QDialogButtonBox.ButtonRole.RejectRole)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)


class CreateRoomDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Nova sala")
        self.setModal(True)
        self.setMinimumWidth(360)
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 16)
        form = QFormLayout()
        self._name  = QLineEdit()
        self._name.setPlaceholderText("nom-sala")
        self._topic = QLineEdit()
        self._topic.setPlaceholderText("Tema opcional")
        form.addRow("Nom:", self._name)
        form.addRow("Tema:", self._topic)
        layout.addLayout(form)
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self._name.setFocus()

    @property
    def room_name(self): return self._name.text().strip()
    @property
    def room_topic(self): return self._topic.text().strip()


# ─────────────────────────────────────────────────────────
#  Widget de progrés de transferència
# ─────────────────────────────────────────────────────────

class TransferWidget(QWidget):
    cancel_requested = pyqtSignal(str)  # file_id

    def __init__(self, file_id, filename, direction, parent=None):
        super().__init__(parent)
        self.file_id = file_id
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)

        label = "Enviant" if direction == "send" else "Rebent"
        self._lbl = QLabel(f"{label}: {filename}")
        self._lbl.setStyleSheet("color:#e5e9f0; font-size:11px;")
        self._lbl.setMaximumWidth(210)
        layout.addWidget(self._lbl)

        self._bar = QProgressBar()
        self._bar.setMaximum(100)
        self._bar.setFixedHeight(12)
        self._bar.setMinimumWidth(110)
        layout.addWidget(self._bar)

        self._pct_lbl = QLabel("0%")
        self._pct_lbl.setStyleSheet("color:#8d99aa; font-size:10px;")
        self._pct_lbl.setFixedWidth(32)
        layout.addWidget(self._pct_lbl)

        cancel = QPushButton("Cancel")
        cancel.setObjectName("secondary_btn")
        cancel.setFixedHeight(26)
        cancel.setStyleSheet(
            "QPushButton{padding:3px 8px;font-size:11px;}"
        )
        cancel.clicked.connect(lambda: self.cancel_requested.emit(self.file_id))
        layout.addWidget(cancel)

    def set_progress(self, pct: float):
        v = int(pct * 100)
        self._bar.setValue(v)
        self._pct_lbl.setText(f"{v}%")


# ─────────────────────────────────────────────────────────
#  Finestra principal
# ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    # Signals per fer thread-safe els callbacks de xarxa
    _sig_auth_ok      = pyqtSignal(object)
    _sig_auth_fail    = pyqtSignal(object)
    _sig_message      = pyqtSignal(object)
    _sig_broadcast    = pyqtSignal(object)
    _sig_user_join    = pyqtSignal(object)
    _sig_user_leave   = pyqtSignal(object)
    _sig_user_list    = pyqtSignal(object)
    _sig_room_list    = pyqtSignal(object)
    _sig_room_created = pyqtSignal(object)
    _sig_history      = pyqtSignal(object)
    _sig_dm_history   = pyqtSignal(object)
    _sig_heartbeat    = pyqtSignal(object)
    _sig_typing       = pyqtSignal(object)
    _sig_react        = pyqtSignal(object)
    _sig_file_notify  = pyqtSignal(object)
    _sig_file_progress= pyqtSignal(str, float, str, str)  # id, pct, name, dir
    _sig_file_done    = pyqtSignal(str, object, bool, str, str)
    _sig_file_reject  = pyqtSignal(object)
    _sig_file_cancel  = pyqtSignal(object)
    _sig_notification = pyqtSignal(object)
    _sig_error        = pyqtSignal(object)
    _sig_disconnect   = pyqtSignal()
    _sig_ping         = pyqtSignal(float)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("NexusLAN")
        self.setMinimumSize(1120, 720)

        self._client: Optional[NexusClient] = None
        self._users: Dict[str, dict] = {}
        self._current_target = "#general"
        self._server_ip = ""
        self._my_uid    = ""
        self._my_role   = "user"
        self._transfers: Dict[str, TransferWidget] = {}
        self._typing_timers: Dict[str, QTimer] = {}

        qss = Path(__file__).parent / "styles" / "dark_theme.qss"
        self.setStyleSheet(load_stylesheet(str(qss)))

        self._build_ui()
        self._connect_signals()

    # ─── UI Construction ───────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())
        root.addWidget(self._vline())

        # Zona central (xat + transferències actives)
        mid = QVBoxLayout()
        mid.setContentsMargins(0, 0, 0, 0)
        mid.setSpacing(0)

        self._chat = ChatView()
        self._chat.message_sent.connect(self._on_message_sent)
        self._chat.file_attach.connect(self._on_file_attach)
        self._chat.set_connected(False)
        mid.addWidget(self._chat, stretch=1)

        # Zona de transferències actives
        self._transfer_bar = QWidget()
        self._transfer_bar.setStyleSheet("background:#151922; border-top:1px solid #252b36;")
        self._transfer_layout = QHBoxLayout(self._transfer_bar)
        self._transfer_layout.setContentsMargins(8, 4, 8, 4)
        self._transfer_layout.addStretch()
        self._transfer_bar.setVisible(False)
        mid.addWidget(self._transfer_bar)

        mid_w = QWidget()
        mid_w.setLayout(mid)
        root.addWidget(mid_w, stretch=1)

        root.addWidget(self._vline())
        self._users_panel = UsersPanel()
        self._users_panel.private_message_requested.connect(self._on_private_chat)
        root.addWidget(self._users_panel)

        self._chat.add_system("Benvingut a NexusLAN. Connecta't per comencar.")
        self._chat.add_system("Comandes disponibles: /broadcast <text>, /rooms, /clear, /ping")

    def _build_sidebar(self) -> QWidget:
        w = QWidget()
        w.setObjectName("sidebar")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        logo = QLabel("NexusLAN")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet(
            "color:#f4f7fb;font-size:20px;font-weight:800;"
            "padding:18px 0 14px 0;"
        )
        lay.addWidget(logo)
        lay.addWidget(self._hline())

        rooms_lbl = QLabel("Sales")
        rooms_lbl.setObjectName("section_label")
        lay.addWidget(rooms_lbl)

        self._rooms_list = QListWidget()
        self._rooms_list.setObjectName("room_list")
        self._rooms_list.currentItemChanged.connect(self._on_room_changed)
        lay.addWidget(self._rooms_list)

        self._new_room_btn = QPushButton("+ Nova sala")
        self._new_room_btn.setObjectName("secondary_btn")
        self._new_room_btn.setEnabled(False)
        self._new_room_btn.setStyleSheet("margin:6px 12px 8px 12px;font-size:11px;")
        self._new_room_btn.clicked.connect(self._on_create_room)
        lay.addWidget(self._new_room_btn)

        dm_lbl = QLabel("Missatges directes")
        dm_lbl.setObjectName("section_label")
        lay.addWidget(dm_lbl)

        self._dm_list = QListWidget()
        self._dm_list.setObjectName("room_list")
        self._dm_list.currentItemChanged.connect(self._on_dm_changed)
        lay.addWidget(self._dm_list)

        # Botó descàrregues
        dl_btn = QPushButton("Obrir descarregues")
        dl_btn.setObjectName("secondary_btn")
        dl_btn.setStyleSheet("margin:8px 12px 4px 12px;font-size:11px;")
        dl_btn.clicked.connect(self._open_downloads)
        lay.addWidget(dl_btn)

        self._status_label = QLabel("Desconnectat")
        self._status_label.setStyleSheet("color:#ff6b7a;font-size:11px;padding:8px 14px;")
        lay.addWidget(self._status_label)

        self._connect_btn = QPushButton("Connectar")
        self._connect_btn.setStyleSheet("margin:4px 12px 14px 12px;")
        self._connect_btn.clicked.connect(self._on_connect_clicked)
        lay.addWidget(self._connect_btn)

        return w

    def _vline(self):
        f = QFrame()
        f.setFrameShape(QFrame.Shape.VLine)
        f.setStyleSheet("color:#252b36;")
        return f

    def _hline(self):
        f = QFrame()
        f.setFrameShape(QFrame.Shape.HLine)
        f.setStyleSheet("color:#252b36;")
        return f

    # ─── Signal connections ────────────────────────────────────────────

    def _connect_signals(self):
        self._sig_auth_ok.connect(self._on_auth_ok)
        self._sig_auth_fail.connect(self._on_auth_fail)
        self._sig_message.connect(self._on_msg_received)
        self._sig_broadcast.connect(self._on_broadcast)
        self._sig_user_join.connect(self._on_user_join)
        self._sig_user_leave.connect(self._on_user_leave)
        self._sig_user_list.connect(self._on_user_list)
        self._sig_room_list.connect(self._on_room_list)
        self._sig_room_created.connect(self._on_room_created)
        self._sig_history.connect(self._on_history)
        self._sig_dm_history.connect(self._on_dm_history)
        self._sig_heartbeat.connect(self._on_heartbeat_msg)
        self._sig_typing.connect(self._on_typing)
        self._sig_react.connect(self._on_react)
        self._sig_file_notify.connect(self._on_file_notify)
        self._sig_file_progress.connect(self._on_file_progress)
        self._sig_file_done.connect(self._on_file_done)
        self._sig_file_reject.connect(self._on_file_reject)
        self._sig_file_cancel.connect(self._on_file_cancel)
        self._sig_notification.connect(self._on_notification)
        self._sig_error.connect(self._on_error_msg)
        self._sig_disconnect.connect(self._on_disconnected)
        self._sig_ping.connect(self._on_ping_update)

    # ─── Connect flow ──────────────────────────────────────────────────

    def _on_connect_clicked(self):
        dlg = LoginDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            asyncio.ensure_future(self._connect(
                dlg.username, dlg.hostname, dlg.server_ip))

    async def _connect(self, username, hostname, server_ip):
        self._chat.add_system(f"Connectant com {username}@{hostname}...")
        self._connect_btn.setEnabled(False)

        self._client = NexusClient(username, hostname)
        # Assignar callbacks via signals (thread-safe)
        self._client.on_auth_ok      = self._sig_auth_ok.emit
        self._client.on_auth_fail    = self._sig_auth_fail.emit
        self._client.on_message      = self._sig_message.emit
        self._client.on_broadcast    = self._sig_broadcast.emit
        self._client.on_user_join    = self._sig_user_join.emit
        self._client.on_user_leave   = self._sig_user_leave.emit
        self._client.on_user_list    = self._sig_user_list.emit
        self._client.on_room_list    = self._sig_room_list.emit
        self._client.on_room_created = self._sig_room_created.emit
        self._client.on_history      = self._sig_history.emit
        self._client.on_dm_history   = self._sig_dm_history.emit
        self._client.on_heartbeat    = self._sig_heartbeat.emit
        self._client.on_typing       = self._sig_typing.emit
        self._client.on_react        = self._sig_react.emit
        self._client.on_file_notify  = self._sig_file_notify.emit
        self._client.on_file_progress= self._sig_file_progress.emit
        self._client.on_file_done    = self._sig_file_done.emit
        self._client.on_file_reject  = self._sig_file_reject.emit
        self._client.on_file_cancel  = self._sig_file_cancel.emit
        self._client.on_notification = self._sig_notification.emit
        self._client.on_error        = self._sig_error.emit
        self._client.on_disconnect   = self._sig_disconnect.emit
        self._client.on_ping_update  = self._sig_ping.emit

        ok = await self._client.connect(server_ip)
        if not ok:
            self._chat.add_system(
                "No s'ha pogut connectar. Comprova que el servidor estigui actiu "
                "i la IP sigui correcta.")
            self._connect_btn.setEnabled(True)

    # ─── Network callbacks (via signals, al thread de Qt) ─────────────

    @pyqtSlot(object)
    def _on_auth_ok(self, msg: Message):
        data = msg.data or {}
        self._my_role = data.get("role", "user")
        self._my_uid  = data.get("uid", self._client.uid if self._client else "")
        self._server_ip = self._client._server_ip or ""

        self._chat.set_connected(True)
        self._chat.set_server_info(self._server_ip)
        self._status_label.setText(f"Connectat - {self._my_role}")
        self._status_label.setStyleSheet(
            "color:#48d6c9;font-size:11px;padding:8px 14px;")
        self._connect_btn.setText("Desconnectar")
        self._connect_btn.setEnabled(True)
        try:
            self._connect_btn.clicked.disconnect()
        except Exception:
            pass
        self._connect_btn.clicked.connect(self._on_disconnect_clicked)
        self._new_room_btn.setEnabled(True)
        self._chat.add_system(
            f"Connectat com {self._my_uid} (rol: {self._my_role})")

    @pyqtSlot(object)
    def _on_auth_fail(self, msg: Message):
        self._chat.add_system(f"Autenticacio fallida: {msg.content}")
        self._connect_btn.setEnabled(True)

    @pyqtSlot(object)
    def _on_msg_received(self, msg: Message):
        to       = msg.to or ""
        is_dm    = not to.startswith("#")
        from_uid = f"{msg.from_user}@{msg.from_host}"

        if is_dm:
            # Si sóc el receptor, el sender és from_uid
            # Si sóc el sender (echo), el destinatari és to
            other_uid = from_uid if from_uid != self._my_uid else to
            # Assegurar que existeix la conversa al sidebar
            self._ensure_dm(other_uid, mark_unread=(other_uid != self._current_target))
            # Mostrar al xat si és la conversa activa
            if self._current_target == other_uid or self._current_target == from_uid:
                self._chat.add_message(
                    msg.from_user, msg.from_host,
                    msg.content or "", msg.timestamp, is_private=True)
        else:
            # Missatge de sala
            if self._current_target == to:
                self._chat.add_message(
                    msg.from_user, msg.from_host,
                    msg.content or "", msg.timestamp)

    @pyqtSlot(object)
    def _on_broadcast(self, msg: Message):
        self._chat.add_broadcast(msg.from_user or "server",
                                  msg.content or "", msg.timestamp)

    @pyqtSlot(object)
    def _on_user_join(self, msg: Message):
        data = msg.data or {}
        uid  = data.get("uid", "")
        self._users[uid] = data
        self._users_panel.update_user(data)
        self._chat.add_system(f"{uid} s'ha connectat")

    @pyqtSlot(object)
    def _on_user_leave(self, msg: Message):
        data = msg.data or {}
        uid  = data.get("uid", "")
        self._users.pop(uid, None)
        self._users_panel.remove_user(uid)
        self._chat.add_system(f"{uid} s'ha desconnectat")

    @pyqtSlot(object)
    def _on_user_list(self, msg: Message):
        users = (msg.data or {}).get("users", [])
        self._users = {u["uid"]: u for u in users if "uid" in u}
        self._users_panel.set_users(users)

    @pyqtSlot(object)
    def _on_room_list(self, msg: Message):
        rooms = (msg.data or {}).get("rooms", [])
        self._rooms_list.clear()
        for r in rooms:
            item = QListWidgetItem(f"# {r['name']}")
            item.setData(Qt.ItemDataRole.UserRole, r["name"])
            tip  = r.get("topic", "")
            cnt  = r.get("member_count", 0)
            if tip:
                item.setToolTip(f"{tip} · {cnt} membres")
            self._rooms_list.addItem(item)
        # Seleccionar general
        for i in range(self._rooms_list.count()):
            if self._rooms_list.item(i).data(Qt.ItemDataRole.UserRole) == "general":
                self._rooms_list.setCurrentRow(i)
                break

    @pyqtSlot(object)
    def _on_room_created(self, msg: Message):
        data = msg.data or {}
        name = data.get("name", "")
        self._chat.add_system(f"Sala #{name} creada per {msg.from_user}")
        if self._client:
            asyncio.ensure_future(self._client.request_room_list())

    @pyqtSlot(object)
    def _on_history(self, msg: Message):
        data     = msg.data or {}
        room     = data.get("room", "")
        messages = data.get("messages", [])
        # Mostrar historial només si és la sala activa
        if self._current_target == f"#{room}":
            self._chat.add_history(messages)

    @pyqtSlot(object)
    def _on_dm_history(self, msg: Message):
        data     = msg.data or {}
        with_uid = data.get("with", "")
        messages = data.get("messages", [])
        if self._current_target == with_uid:
            self._chat.add_history(messages)

    @pyqtSlot(object)
    def _on_heartbeat_msg(self, msg: Message):
        data = msg.data or {}
        uid  = data.get("uid", f"{msg.from_user}@{msg.from_host}")
        if uid:
            self._users[uid] = data
            self._users_panel.update_user(data)

    @pyqtSlot(object)
    def _on_typing(self, msg: Message):
        from_uid  = f"{msg.from_user}@{msg.from_host}"
        is_typing = (msg.data or {}).get("typing", True)
        to        = msg.to or ""

        # Mostrar si afecta la conversa activa
        relevant = (to == self._current_target or
                    (not to.startswith("#") and from_uid == self._current_target))
        if not relevant:
            return

        if is_typing:
            self._chat.show_typing(msg.from_user or "")
            timer = self._typing_timers.get(from_uid)
            if timer:
                timer.stop()
            t = QTimer(self)
            t.setSingleShot(True)
            t.timeout.connect(lambda u=msg.from_user: self._chat.hide_typing(u or ""))
            t.start(3500)
            self._typing_timers[from_uid] = t
        else:
            self._chat.hide_typing(msg.from_user or "")

    @pyqtSlot(object)
    def _on_react(self, msg: Message):
        data  = msg.data or {}
        emoji = data.get("emoji", "")
        mid   = data.get("msg_id", "")
        self._chat.add_reaction(mid, msg.from_user or "", emoji)

    @pyqtSlot(object)
    def _on_file_notify(self, msg: Message):
        data     = msg.data or {}
        from_uid = f"{msg.from_user}@{msg.from_host}"
        filename = data.get("filename", "?")
        size     = data.get("size", 0)
        file_id  = data.get("file_id", "")

        dlg = FileNotifyDialog(from_uid, filename, size, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._chat.add_system(f"Acceptat {filename} de {from_uid}")
            # Afegir widget de progrés
            self._add_transfer_widget(file_id, filename, "recv")
            asyncio.ensure_future(self._client.accept_file(from_uid, file_id))
        else:
            self._chat.add_system(f"Rebutjat {filename}")
            asyncio.ensure_future(self._client.reject_file(from_uid, file_id))

    @pyqtSlot(str, float, str, str)
    def _on_file_progress(self, file_id: str, pct: float, filename: str, direction: str):
        w = self._transfers.get(file_id)
        if w:
            w.set_progress(pct)

    @pyqtSlot(str, object, bool, str, str)
    def _on_file_done(self, file_id: str, path, checksum_ok: bool,
                      filename: str, from_uid: str):
        self._remove_transfer_widget(file_id)
        if path:
            icon = "OK" if checksum_ok else "Avis"
            chk  = "" if checksum_ok else " (checksum erroni!)"
            self._chat.add_system(
                f"{icon}: fitxer rebut: {filename} -> {path}{chk}")
        else:
            self._chat.add_system(f"Error en rebre {filename}")

    @pyqtSlot(object)
    def _on_file_reject(self, msg: Message):
        fid = (msg.data or {}).get("file_id", "")
        self._remove_transfer_widget(fid)
        self._chat.add_system("El destinatari ha rebutjat el fitxer.")

    @pyqtSlot(object)
    def _on_file_cancel(self, msg: Message):
        fid = (msg.data or {}).get("file_id", "")
        self._remove_transfer_widget(fid)
        self._chat.add_system("El remitent ha cancel-lat la transferencia.")

    @pyqtSlot(object)
    def _on_notification(self, msg: Message):
        self._chat.add_system(str(msg.content))

    @pyqtSlot(object)
    def _on_error_msg(self, msg: Message):
        self._chat.add_system(f"Error: {msg.content}")

    @pyqtSlot()
    def _on_disconnected(self):
        self._chat.set_connected(False)
        self._chat.add_system("Connexio perduda. Intentant reconnectar...")
        self._status_label.setText("Reconnectant...")
        self._status_label.setStyleSheet(
            "color:#f6b85f;font-size:11px;padding:8px 14px;")
        self._new_room_btn.setEnabled(False)

    @pyqtSlot(float)
    def _on_ping_update(self, ms: float):
        self._chat.set_server_info(self._server_ip, int(ms))

    # ─── UI interactions ───────────────────────────────────────────────

    def _on_room_changed(self, current, previous):
        if not current:
            return
        room = current.data(Qt.ItemDataRole.UserRole)
        if not room:
            return
        self._dm_list.clearSelection()
        self._current_target = f"#{room}"
        self._chat.set_target(f"#{room}", room)
        if self._client and self._client.connected:
            asyncio.ensure_future(self._client.join_room(room))

    def _on_dm_changed(self, current, previous):
        if not current:
            return
        uid = current.data(Qt.ItemDataRole.UserRole)
        if not uid:
            return
        self._rooms_list.clearSelection()
        self._current_target = uid
        self._chat.set_target(uid, uid)
        # Netejar badge
        current.setText(f"DM  {uid}")
        if self._client and self._client.connected:
            asyncio.ensure_future(self._client.request_dm_history(uid))

    @pyqtSlot(str)
    def _on_private_chat(self, uid: str):
        self._ensure_dm(uid, mark_unread=False)

    def _ensure_dm(self, uid: str, mark_unread: bool = False):
        for i in range(self._dm_list.count()):
            item = self._dm_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == uid:
                if mark_unread and self._current_target != uid:
                    base = uid
                    if "Nou" not in item.text():
                        item.setText(f"Nou  {base}")
                else:
                    self._dm_list.setCurrentRow(i)
                return
        # No existeix: crear-lo
        item = QListWidgetItem(f"{'Nou  ' if mark_unread else 'DM  '}{uid}")
        item.setData(Qt.ItemDataRole.UserRole, uid)
        self._dm_list.addItem(item)
        if not mark_unread:
            self._dm_list.setCurrentItem(item)

    def _on_message_sent(self, to: str, content: str):
        if not self._client or not self._client.connected:
            return
        # Comandes especials
        if content.startswith("/"):
            self._handle_command(content)
            return
        # Enviar indicador d'escriptura off
        asyncio.ensure_future(self._client.send_typing(to, False))
        asyncio.ensure_future(self._client.send_chat(to, content))

    def _handle_command(self, cmd: str):
        parts = cmd.strip().split(None, 2)
        verb  = parts[0].lower()
        if verb == "/broadcast" and len(parts) > 1:
            text = " ".join(parts[1:])
            asyncio.ensure_future(self._client.send_broadcast(text))
        elif verb == "/clear":
            self._chat._display.clear_chat()
        elif verb == "/ping":
            asyncio.ensure_future(self._client._send(
                __import__("shared.protocol.messages",
                           fromlist=["Message"]).Message(type="ping")))
        else:
            self._chat.add_system(f"Comanda desconeguda: {verb}")

    def _on_file_attach(self, to: str):
        if not self._client or not self._client.connected:
            return
        if to.startswith("#"):
            self._chat.add_system(
                "La transferencia de fitxers es per DM. "
                "Clica un usuari del panel de la dreta primer.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Selecciona fitxer", str(Path.home()), "Tots (*)")
        if path:
            asyncio.ensure_future(self._send_file_async(path, to))

    async def _send_file_async(self, filepath: str, to_uid: str):
        p = Path(filepath)
        file_id = ""
        # Afegir widget de progrés (necessitem el file_id, es crea dins send_file)
        # Guardem el path per mostrar-lo
        self._chat.add_system(f"Enviant {p.name} a {to_uid}...")

        # Crear un FileSender temporal per obtenir el file_id
        # Alternativament cridem directament send_file
        import uuid as _uuid
        preview_id = str(_uuid.uuid4())[:8]
        self._add_transfer_widget(preview_id, p.name, "send")

        ok = await self._client.send_file(filepath, to_uid)

        self._remove_transfer_widget(preview_id)
        if ok:
            self._chat.add_system(f"{p.name} enviat correctament a {to_uid}")
        else:
            self._chat.add_system(f"Enviament de {p.name} cancel-lat o rebutjat")

    def _on_create_room(self):
        dlg = CreateRoomDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.room_name:
            asyncio.ensure_future(
                self._client.create_room(dlg.room_name, dlg.room_topic))

    def _on_disconnect_clicked(self):
        if self._client:
            asyncio.ensure_future(self._client.disconnect())
        self._status_label.setText("Desconnectat")
        self._status_label.setStyleSheet(
            "color:#ff6b7a;font-size:11px;padding:8px 14px;")
        self._connect_btn.setText("Connectar")
        self._new_room_btn.setEnabled(False)
        try:
            self._connect_btn.clicked.disconnect()
        except Exception:
            pass
        self._connect_btn.clicked.connect(self._on_connect_clicked)

    def _open_downloads(self):
        import subprocess, sys
        path = str(get_downloads_dir())
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])

    # ─── Transfer widget helpers ───────────────────────────────────────

    def _add_transfer_widget(self, file_id: str, filename: str, direction: str):
        w = TransferWidget(file_id, filename, direction)
        w.cancel_requested.connect(self._on_cancel_transfer)
        # Inserir abans de l'stretch
        idx = self._transfer_layout.count() - 1
        self._transfer_layout.insertWidget(idx, w)
        self._transfers[file_id] = w
        self._transfer_bar.setVisible(True)

    def _remove_transfer_widget(self, file_id: str):
        w = self._transfers.pop(file_id, None)
        if w:
            self._transfer_layout.removeWidget(w)
            w.deleteLater()
        if not self._transfers:
            self._transfer_bar.setVisible(False)

    @pyqtSlot(str)
    def _on_cancel_transfer(self, file_id: str):
        if self._client:
            asyncio.ensure_future(self._client.cancel_send(file_id))
        self._remove_transfer_widget(file_id)

    def closeEvent(self, event):
        if self._client:
            asyncio.ensure_future(self._client.disconnect())
        event.accept()
