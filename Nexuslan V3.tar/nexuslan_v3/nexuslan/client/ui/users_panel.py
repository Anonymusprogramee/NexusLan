"""
client/ui/users_panel.py
Panel lateral dret amb usuaris online i stats de sistema.
"""
import time
from typing import Dict
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QScrollArea,
    QFrame, QHBoxLayout, QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont


def _status_color(status: str) -> str:
    return {"online": "#48d6c9", "idle": "#f6b85f"}.get(status, "#ff6b7a")


def _status_dot(status: str) -> str:
    return {"online": "ON", "idle": "ID"}.get(status, "OFF")


class UserCard(QFrame):
    clicked = pyqtSignal(str)  # uid

    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.uid = data.get("uid", "")
        self.setObjectName("user_card")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._build(data)

    def _build(self, data: dict):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(4)

        # Línia 1: dot + nom
        top = QHBoxLayout()
        top.setSpacing(6)
        
        status = data.get("status", "offline")
        dot = QLabel(_status_dot(status))
        dot.setStyleSheet(
            f"color: {_status_color(status)}; font-size: 10px; "
            "font-weight: 700; min-width: 24px;"
        )
        top.addWidget(dot)

        name = QLabel(f"{data.get('username', '?')} <span style='color:#8d99aa'>@{data.get('hostname','')}</span>")
        name.setTextFormat(Qt.TextFormat.RichText)
        name.setFont(QFont("Segoe UI", 11))
        name.setWordWrap(True)
        top.addWidget(name)
        top.addStretch()
        
        role = data.get("role", "user")
        if role in ("admin", "moderator"):
            badge = QLabel(f"[{role}]")
            badge.setStyleSheet("color: #f6b85f; font-size: 10px; font-weight: 700;")
            top.addWidget(badge)
        
        layout.addLayout(top)

        # Línia 2: CPU + RAM
        stats = data.get("cpu"), data.get("ram")
        if any(stats):
            bar_label = QLabel(
                f"<span style='color:#8d99aa'>CPU</span> "
                f"<span style='color:#48d6c9'>{data.get('cpu',0):.0f}%</span>  "
                f"<span style='color:#8d99aa'>RAM</span> "
                f"<span style='color:#48d6c9'>{data.get('ram',0):.0f}%</span>"
            )
            bar_label.setTextFormat(Qt.TextFormat.RichText)
            bar_label.setFont(QFont("Segoe UI", 10))
            layout.addWidget(bar_label)
        
        if status == "idle":
            idle_lbl = QLabel("Inactiu")
            idle_lbl.setStyleSheet("color: #f6b85f; font-size: 10px;")
            layout.addWidget(idle_lbl)

    def mousePressEvent(self, event):
        self.clicked.emit(self.uid)
        super().mousePressEvent(event)

    def update_data(self, data: dict):
        # Reconstruir el card amb dades noves
        for child in self.children():
            if hasattr(child, "deleteLater"):
                child.deleteLater()
        old_layout = self.layout()
        if old_layout:
            QWidget().setLayout(old_layout)
        self._build(data)


class UsersPanel(QWidget):
    private_message_requested = pyqtSignal(str)  # uid

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("users_panel")
        self._cards: Dict[str, UserCard] = {}
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Capçalera
        hdr = QLabel("Usuaris online")
        hdr.setObjectName("section_label")
        hdr.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(hdr)

        self._count_label = QLabel("0 connectats")
        self._count_label.setStyleSheet("color: #8d99aa; font-size: 11px; padding: 0 14px 6px 14px;")
        layout.addWidget(self._count_label)

        # Scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        self._container = QWidget()
        self._list_layout = QVBoxLayout(self._container)
        self._list_layout.setContentsMargins(0, 6, 0, 8)
        self._list_layout.setSpacing(0)
        self._list_layout.addStretch()
        
        scroll.setWidget(self._container)
        layout.addWidget(scroll)

    def set_users(self, users: list):
        """Actualitza tota la llista d'usuaris."""
        # Eliminar tots i reconstruir
        while self._list_layout.count() > 1:
            item = self._list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._cards.clear()
        
        for u in users:
            self._add_card(u)
        
        online = sum(1 for u in users if u.get("status") != "offline")
        self._count_label.setText(f"{online} connectats")

    def update_user(self, data: dict):
        """Actualitza o afegeix un usuari."""
        uid = data.get("uid", "")
        if uid in self._cards:
            # Reconstruir card
            card = self._cards[uid]
            idx = self._list_layout.indexOf(card)
            self._list_layout.removeWidget(card)
            card.deleteLater()
            new_card = self._make_card(data)
            self._list_layout.insertWidget(idx, new_card)
            self._cards[uid] = new_card
        else:
            self._add_card(data)

    def remove_user(self, uid: str):
        if uid in self._cards:
            card = self._cards.pop(uid)
            self._list_layout.removeWidget(card)
            card.deleteLater()

    def _add_card(self, data: dict):
        card = self._make_card(data)
        self._list_layout.insertWidget(self._list_layout.count() - 1, card)
        self._cards[data.get("uid", "")] = card

    def _make_card(self, data: dict) -> UserCard:
        card = UserCard(data)
        card.clicked.connect(self.private_message_requested.emit)
        return card
