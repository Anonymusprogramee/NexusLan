"""
client/ui/chat_view.py  v3
Millores:
 - Indicador d'escriptura visible
 - Reaccions amb emoji
 - Input debounce per enviar typing
 - Cerca de missatges
 - Auto-scroll intel·ligent
"""
import time
from datetime import datetime
from typing import Dict, Set

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextBrowser,
    QLineEdit, QPushButton, QLabel, QFrame, QFileDialog,
    QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QTextCursor


def _fmt_time(ts: int) -> str:
    return datetime.fromtimestamp(ts).strftime("%H:%M")


def _esc(text: str) -> str:
    return (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>"))


class ChatDisplay(QTextBrowser):
    """Historial de missatges enriquit."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("chat_display")
        self.setReadOnly(True)
        self.setOpenLinks(False)
        self.setFont(QFont("Segoe UI", 12))
        self._last_sender = ""
        self._msg_ids: Dict[str, str] = {}  # msg_id → àncora HTML (no usada directament)
        self._at_bottom = True
        self.verticalScrollBar().valueChanged.connect(self._on_scroll)

    def _on_scroll(self, val):
        sb  = self.verticalScrollBar()
        self._at_bottom = val >= sb.maximum() - 5

    def _scroll_bottom(self):
        if self._at_bottom:
            sb = self.verticalScrollBar()
            sb.setValue(sb.maximum())

    def add_message(self, from_user: str, from_host: str, content: str,
                    timestamp: int, is_private: bool = False, msg_id: str = ""):
        ts     = _fmt_time(timestamp)
        sender = f"{from_user}@{from_host}"
        body   = _esc(content)

        if sender != self._last_sender:
            color = "#48d6c9" if not is_private else "#f1a7d8"
            html  = (
                f'<div style="margin-top:12px;">'
                f'<span style="color:{color};font-weight:bold">{_esc(sender)}</span>'
                f'<span style="color:#758194;font-size:10px;margin-left:8px">{ts}</span>'
                f'</div>'
                f'<div style="color:#e5e9f0;padding-left:4px;margin-top:3px;line-height:1.35">{body}</div>'
            )
            self._last_sender = sender
        else:
            html = (
                f'<div style="color:#e5e9f0;padding-left:4px;margin-top:2px;line-height:1.35">'
                f'<span style="color:#4f5a6b;font-size:10px">{ts} </span>'
                f'{body}</div>'
            )
        self.append(html)
        self._scroll_bottom()

    def add_broadcast(self, from_user: str, content: str, timestamp: int):
        ts   = _fmt_time(timestamp)
        html = (
            f'<div style="margin:8px 0;padding:8px 12px;'
            f'background:#241b12;border-left:3px solid #f6b85f;border-radius:6px;">'
            f'<span style="color:#f6b85f;font-weight:bold">Broadcast</span>'
            f'<span style="color:#758194;font-size:10px;margin-left:8px">{ts}</span><br>'
            f'<span style="color:#f9d89b">{_esc(content)}</span>'
            f'</div>'
        )
        self._last_sender = ""
        self.append(html)
        self._scroll_bottom()

    def add_system(self, text: str):
        html = (f'<div style="color:#7f8b9d;font-size:11px;'
                f'margin:7px 0;text-align:center">{_esc(text)}</div>')
        self._last_sender = ""
        self.append(html)
        self._scroll_bottom()

    def add_history(self, messages: list):
        if not messages:
            return
        self.add_system("Historial")
        for m in messages:
            self.add_message(
                m.get("from_user", "?"),
                m.get("from_host", ""),
                m.get("content", ""),
                m.get("timestamp", int(time.time()))
            )
        self.add_system("Fi d'historial")

    def add_reaction(self, msg_id: str, from_user: str, emoji: str):
        html = (f'<div style="color:#8d99aa;font-size:11px;margin-top:2px;">'
                f'<span style="font-size:14px">{emoji}</span>'
                f' <span style="color:#8d99aa">{_esc(from_user)}</span>'
                f'</div>')
        self.append(html)
        self._scroll_bottom()

    def clear_chat(self):
        self.clear()
        self._last_sender = ""


class TypingIndicator(QLabel):
    """Mostra qui està escrivint."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("color:#8d99aa;font-size:11px;padding:4px 12px;min-height:20px;")
        self._typing: Set[str] = set()
        self._update()

    def add(self, user: str):
        self._typing.add(user)
        self._update()

    def remove(self, user: str):
        self._typing.discard(user)
        self._update()

    def _update(self):
        if not self._typing:
            self.setText("")
        elif len(self._typing) == 1:
            u = next(iter(self._typing))
            self.setText(f"{u} esta escrivint...")
        else:
            users = ", ".join(list(self._typing)[:3])
            self.setText(f"{users} estan escrivint...")


class InputBar(QWidget):
    message_sent  = pyqtSignal(str)
    file_attach   = pyqtSignal()
    typing_change = pyqtSignal(bool)  # True=escrivint, False=parat

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("input_bar")
        self._typing     = False
        self._stop_timer = QTimer(self)
        self._stop_timer.setSingleShot(True)
        self._stop_timer.timeout.connect(self._on_stop_typing)
        self._build()

    def _build(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        self._attach = QPushButton("+")
        self._attach.setObjectName("attach_btn")
        self._attach.setToolTip("Adjuntar fitxer (DM)")
        self._attach.setFixedWidth(38)
        self._attach.clicked.connect(self.file_attach.emit)
        layout.addWidget(self._attach)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Escriu un missatge... (/ajuda per comandes)")
        self._input.returnPressed.connect(self._send)
        self._input.textChanged.connect(self._on_text_changed)
        layout.addWidget(self._input)

        # Emojis ràpids
        for emoji in ("😀", "👍", "❤️", "😂", "🤔"):
            btn = QPushButton(emoji)
            btn.setFixedWidth(30)
            btn.setStyleSheet(
                "QPushButton{background:transparent;border:none;font-size:14px;}"
                "QPushButton:hover{background:#1c222d;border-radius:6px;}"
            )
            btn.clicked.connect(lambda _, e=emoji: self._insert_emoji(e))
            layout.addWidget(btn)

        self._send_btn = QPushButton("Envia")
        self._send_btn.setObjectName("send_btn")
        self._send_btn.setFixedWidth(78)
        self._send_btn.clicked.connect(self._send)
        layout.addWidget(self._send_btn)

    def _insert_emoji(self, emoji: str):
        pos = self._input.cursorPosition()
        txt = self._input.text()
        self._input.setText(txt[:pos] + emoji + txt[pos:])
        self._input.setCursorPosition(pos + len(emoji))

    def _send(self):
        text = self._input.text().strip()
        if text:
            self.message_sent.emit(text)
            self._input.clear()
            self._on_stop_typing()

    def _on_text_changed(self, text: str):
        if text and not self._typing:
            self._typing = True
            self.typing_change.emit(True)
        elif not text and self._typing:
            self._on_stop_typing()
        if text:
            self._stop_timer.start(3000)

    def _on_stop_typing(self):
        if self._typing:
            self._typing = False
            self.typing_change.emit(False)
        self._stop_timer.stop()

    def set_enabled(self, enabled: bool):
        self._input.setEnabled(enabled)
        self._send_btn.setEnabled(enabled)
        self._attach.setEnabled(enabled)
        self._input.setPlaceholderText(
            "Escriu un missatge... (/ajuda per comandes)"
            if enabled else "No connectat...")


class ChatView(QWidget):
    message_sent = pyqtSignal(str, str)  # (to, content)
    file_attach  = pyqtSignal(str)       # to

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("chat_area")
        self._current_target = "#general"
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(self._build_header())
        layout.addWidget(self._hline())

        self._display = ChatDisplay()
        layout.addWidget(self._display, stretch=1)

        self._typing_ind = TypingIndicator()
        layout.addWidget(self._typing_ind)

        self._input_bar = InputBar()
        self._input_bar.message_sent.connect(self._on_send)
        self._input_bar.file_attach.connect(lambda: self.file_attach.emit(self._current_target))
        self._input_bar.typing_change.connect(self._on_typing_change)
        layout.addWidget(self._input_bar)

    def _build_header(self) -> QWidget:
        w = QWidget()
        w.setObjectName("header_bar")
        h = QHBoxLayout(w)
        h.setContentsMargins(18, 0, 18, 0)
        h.setSpacing(10)

        self._channel_lbl = QLabel("#general")
        self._channel_lbl.setObjectName("header_channel")
        h.addWidget(self._channel_lbl)

        h.addStretch()

        # Cerca
        self._search = QLineEdit()
        self._search.setPlaceholderText("Cerca...")
        self._search.setFixedWidth(190)
        self._search.setStyleSheet(
            "QLineEdit{background:#0f1218;border:1px solid #303746;"
            "border-radius:7px;padding:6px 10px;font-size:12px;color:#aab4c3;}"
            "QLineEdit:focus{border-color:#48d6c9;color:#f4f7fb;}"
        )
        self._search.textChanged.connect(self._on_search)
        h.addWidget(self._search)

        self._stats_lbl = QLabel("NexusLAN")
        self._stats_lbl.setObjectName("header_stats")
        h.addWidget(self._stats_lbl)
        return w

    def _hline(self):
        f = QFrame()
        f.setFrameShape(QFrame.Shape.HLine)
        f.setStyleSheet("color:#1a2540;")
        return f

    # ─── Public API ───────────────────────────────────────────────────

    def set_target(self, target: str, display_name: str = ""):
        self._current_target = target
        lbl = display_name or target
        prefix = "#" if target.startswith("#") else "DM "
        self._channel_lbl.setText(f"{prefix}{lbl.lstrip('#')}")
        self._display.clear_chat()
        self._typing_ind._typing.clear()
        self._typing_ind._update()

    def set_server_info(self, ip: str, ping_ms: int = 0):
        self._stats_lbl.setText(f"Servidor {ip} - {ping_ms} ms")

    def add_message(self, from_user, from_host, content, timestamp,
                    is_private=False, msg_id=""):
        self._display.add_message(from_user, from_host, content, timestamp,
                                   is_private, msg_id)

    def add_broadcast(self, from_user, content, timestamp):
        self._display.add_broadcast(from_user, content, timestamp)

    def add_system(self, text):
        self._display.add_system(text)

    def add_history(self, messages):
        self._display.add_history(messages)

    def add_reaction(self, msg_id, from_user, emoji):
        self._display.add_reaction(msg_id, from_user, emoji)

    def set_connected(self, connected: bool):
        self._input_bar.set_enabled(connected)

    def show_typing(self, user: str):
        self._typing_ind.add(user)

    def hide_typing(self, user: str):
        self._typing_ind.remove(user)

    # ─── Internal ─────────────────────────────────────────────────────

    def _on_send(self, text: str):
        self.message_sent.emit(self._current_target, text)

    def _on_typing_change(self, is_typing: bool):
        # El main_window connectarà aquest signal al client
        pass

    def _on_search(self, query: str):
        if not query:
            return
        # Cerca simple al text del display
        cursor = self._display.document().find(query)
        if not cursor.isNull():
            self._display.setTextCursor(cursor)
