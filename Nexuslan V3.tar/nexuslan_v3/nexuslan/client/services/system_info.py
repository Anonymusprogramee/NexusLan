"""
client/services/system_info.py
Informació del sistema: CPU, RAM, hostname.
"""
import platform
import socket
import psutil


def get_hostname() -> str:
    return socket.gethostname()


def get_os_name() -> str:
    return f"{platform.system()} {platform.release()}"


def get_cpu_percent() -> float:
    return psutil.cpu_percent(interval=None)


def get_ram_percent() -> float:
    return psutil.virtual_memory().percent


def get_system_summary() -> dict:
    return {
        "hostname": get_hostname(),
        "os":       get_os_name(),
        "cpu":      get_cpu_percent(),
        "ram":      get_ram_percent(),
    }
