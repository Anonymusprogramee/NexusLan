"""
shared/encryption/aes_gcm.py
Encriptació AES-256-GCM per a missatges NexusLAN.
Funciona completament en espai d'usuari, sense privilegis.
"""
import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


SALT_SIZE   = 16
NONCE_SIZE  = 12
KEY_SIZE    = 32   # 256 bits


def derive_key(passphrase: str, salt: bytes) -> bytes:
    """Deriva una clau AES-256 d'una frase de pas."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_SIZE,
        salt=salt,
        iterations=100_000,
    )
    return kdf.derive(passphrase.encode())


def generate_room_key() -> bytes:
    """Genera una clau aleatòria de 256 bits per a una sala."""
    return os.urandom(KEY_SIZE)


class NexusCipher:
    """
    Xifratge/desxifratge de missatges amb AES-256-GCM.
    
    Ús:
        cipher = NexusCipher(key_bytes)
        enc = cipher.encrypt("hola món")
        plain = cipher.decrypt(enc)
    """
    
    def __init__(self, key: bytes):
        assert len(key) == KEY_SIZE, f"La clau ha de ser de {KEY_SIZE} bytes"
        self._aesgcm = AESGCM(key)
    
    def encrypt(self, plaintext: str) -> str:
        """Retorna base64(nonce + ciphertext+tag)."""
        nonce = os.urandom(NONCE_SIZE)
        ct    = self._aesgcm.encrypt(nonce, plaintext.encode(), None)
        return base64.b64encode(nonce + ct).decode()
    
    def decrypt(self, token: str) -> str:
        """Desxifra un token generat per encrypt()."""
        raw   = base64.b64decode(token)
        nonce = raw[:NONCE_SIZE]
        ct    = raw[NONCE_SIZE:]
        return self._aesgcm.decrypt(nonce, ct, None).decode()
    
    @classmethod
    def from_passphrase(cls, passphrase: str, salt: Optional[bytes] = None):
        if salt is None:
            salt = os.urandom(SALT_SIZE)
        key = derive_key(passphrase, salt)
        obj = cls(key)
        obj.salt = salt
        return obj


# Importació condicional per evitar error de nom
from typing import Optional
