"""
shared/utils/paths.py
Gestió de paths multiplataforma, sempre dins del directori d'usuari (sense admin).
"""
import os
import sys
from pathlib import Path


def get_app_dir() -> Path:
    """Retorna el directori de configuració de l'app per a l'usuari actual."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home()))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    
    app_dir = base / "nexuslan"
    app_dir.mkdir(parents=True, exist_ok=True)
    return app_dir


def get_db_path() -> Path:
    return get_app_dir() / "nexuslan.db"


def get_logs_dir() -> Path:
    logs = get_app_dir() / "logs"
    logs.mkdir(exist_ok=True)
    return logs


def get_downloads_dir() -> Path:
    if sys.platform == "win32":
        downloads = Path.home() / "Downloads" / "NexusLAN"
    else:
        downloads = Path.home() / "Downloads" / "NexusLAN"
    downloads.mkdir(parents=True, exist_ok=True)
    return downloads


def get_config_path() -> Path:
    return get_app_dir() / "config.json"
