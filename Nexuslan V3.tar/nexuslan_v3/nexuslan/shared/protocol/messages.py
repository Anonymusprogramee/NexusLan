"""
shared/protocol/messages.py
Definició de tots els tipus de missatge del protocol NexusLAN.
"""
from dataclasses import dataclass, asdict, field
from typing import Optional, Any
import time
import uuid
import json


# --- Tipus de missatge ---
MSG_MESSAGE      = "message"
MSG_BROADCAST    = "broadcast"
MSG_FILE_REQUEST = "file_request"
MSG_FILE_NOTIFY  = "file_notify"
MSG_FILE_ACCEPT  = "file_accept"
MSG_FILE_CHUNK   = "file_chunk"
MSG_FILE_DONE    = "file_done"
MSG_HEARTBEAT    = "heartbeat"
MSG_SYSTEM_INFO  = "system_info"
MSG_NOTIFICATION = "notification"
MSG_AUTH         = "auth"
MSG_AUTH_OK      = "auth_ok"
MSG_AUTH_FAIL    = "auth_fail"
MSG_ROOM_JOIN    = "room_join"
MSG_ROOM_LEAVE   = "room_leave"
MSG_ROOM_LIST    = "room_list"
MSG_USER_LIST    = "user_list"
MSG_USER_JOIN    = "user_join"
MSG_USER_LEAVE   = "user_leave"
MSG_HISTORY      = "history"
MSG_ERROR        = "error"
MSG_PING         = "ping"
MSG_PONG         = "pong"
MSG_DM_HISTORY   = "dm_history"
MSG_ROOM_CREATE  = "room_create"
MSG_ROOM_CREATED = "room_created"
MSG_FILE_REJECT  = "file_reject"
MSG_FILE_PROGRESS = "file_progress"
MSG_TYPING       = "typing"


def new_id() -> str:
    return str(uuid.uuid4())[:8]


def now_ts() -> int:
    return int(time.time())


@dataclass
class Message:
    type: str
    msg_id: str = field(default_factory=new_id)
    timestamp: int = field(default_factory=now_ts)
    
    # Camps opcionals
    from_user: Optional[str] = None
    from_host: Optional[str] = None
    to: Optional[str] = None          # sala (#room) o usuari (user@host)
    content: Optional[str] = None
    data: Optional[Any] = None        # payload extra (dict)
    
    def to_json(self) -> str:
        d = {k: v for k, v in asdict(self).items() if v is not None}
        # rename from_user → from per al wire protocol
        if "from_user" in d:
            d["from"] = d.pop("from_user")
        if "from_host" in d:
            d["host"] = d.pop("from_host")
        return json.dumps(d)
    
    @classmethod
    def from_json(cls, raw: str) -> "Message":
        d = json.loads(raw)
        # rename from → from_user
        if "from" in d:
            d["from_user"] = d.pop("from")
        if "host" in d:
            d["from_host"] = d.pop("host")
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


def make_chat(from_user: str, from_host: str, to: str, content: str) -> Message:
    return Message(type=MSG_MESSAGE, from_user=from_user, from_host=from_host,
                   to=to, content=content)


def make_heartbeat(user: str, hostname: str, os_name: str,
                   cpu: float, ram: float, status: str = "online") -> Message:
    return Message(
        type=MSG_HEARTBEAT,
        from_user=user,
        from_host=hostname,
        data={"os": os_name, "cpu_percent": cpu, "ram_percent": ram, "status": status}
    )


def make_auth(username: str, hostname: str, password_hash: Optional[str] = None) -> Message:
    d: dict = {"hostname": hostname}
    if password_hash:
        d["password_hash"] = password_hash
    return Message(type=MSG_AUTH, from_user=username, data=d)


def make_file_request(from_user: str, from_host: str, to: str,
                      filename: str, size: int, file_id: str, checksum: str) -> Message:
    return Message(
        type=MSG_FILE_REQUEST,
        from_user=from_user,
        from_host=from_host,
        to=to,
        data={"filename": filename, "size": size,
              "file_id": file_id, "checksum": checksum}
    )
